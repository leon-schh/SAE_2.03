from django.shortcuts import render
from django.http import HttpResponseRedirect,HttpResponse
from .forms import CommandeForm
from . import models
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def ajout(request,id):
    form = CommandeForm() # création d'un formulaire vide
    return render(request,"commande/ajout.html",{"form" : form,"id":id})

def traitement(request,id):
    lform = CommandeForm(request.POST)
    if lform.is_valid():
        client=models.Client.objects.get(pk=id)
        commande = lform.save(commit=False)
        commande.client_id=id
        commande.save()
        return HttpResponseRedirect(f"/drive/afficheclient/{id}/")
    else:
        return render(request," commande/ajout.html",{"form": lform,"id":id})

def index(request):
    client=list(models.Client.objects.all())
    liste= list(models.Commande.objects.all())
    return render(request,"commande/index.html",{"liste":liste,"client":client})

def affiche(request, id):
    commande = models.Commande.objects.get(pk=id) # méthode pour récupérer les données dans la base avec un id donnée
    liste = models.Client.objects.filter(commande=id)
    return render(request,"commande/affiche.html",{"commande": commande,"liste":liste})

def update(request,id):
    commande = models.Commande.objects.get(pk=id)
    form=CommandeForm(commande.dico())
    return render(request,"commande/update.html",{"form":form,"id":id,"commande":commande.num_commande})

def updatetraitement(request,id):
    lform = CommandeForm(request.POST)
    if lform.is_valid():
        commande= lform.save(commit=False)
        commande.id=id
        commande.save()
        return HttpResponseRedirect("/drive/indexcommande/")
    else:
        return render(request, "commande/ajout.html", {"form": lform,'id':id})

def delete(request,id):
    commande = models.Commande.objects.get(pk=id)
    commande.delete()
    return HttpResponseRedirect("/drive/indexcommande/")
