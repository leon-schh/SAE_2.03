from django.shortcuts import render
from django.http import HttpResponseRedirect,HttpResponse
from .forms import ClientForm
from . import models
from .models import ListeDownloadForm,Liste
from django.views import View
def ajout(request):
    form = ClientForm # création d'un formulaire vide
    return render(request,"client/ajout.html",{"form" : form})

def traitement(request):
    lform = ClientForm(request.POST)
    if lform.is_valid():
        client = lform.save()
        return HttpResponseRedirect("/drive/indexclient/")
    else:
        return render(request,"client/ajout.html",{"form": lform})

def index(request):
    liste= list(models.Client.objects.all())
    return render(request,"client/index.html",{"liste":liste})

def affiche(request, id):
    client = models.Client.objects.get(pk=id) # méthode pour récupérer les données dans la base avec un id donnée
    liste=list(models.Commande.objects.all())
    commande=models.Commande.objects.all()
    return render(request,"client/affiche.html",{"client": client,"liste":liste,"commande":commande})

def update(request,id):
    client = models.Client.objects.get(pk=id)
    form=ClientForm(client.dico())
    return render(request,"client/update.html",{"form":form,"id":id,"client":client.nom})

def updatetraitement(request,id):
    lform = ClientForm(request.POST)
    if lform.is_valid():
        client = lform.save(commit=False)
        client.id=id
        client.save()
        return HttpResponseRedirect("/drive/indexclient/")
    else:
        return render(request, "client/ajout.html", {"form": lform,'id':id})


def delete(request,id):
    client = models.Client.objects.get(pk=id)
    client.delete()
    return HttpResponseRedirect("/drive/indexclient/")

def liste_download(request):
    if request.method == 'POST':
        liste_id = request.POST.get('liste')
        try:
            liste = Liste.objects.get(pk=liste_id)
            response = HttpResponse(liste.contenu, content_type='text/plain')
            response['Content-Disposition'] = f'attachment; filename={liste.nom}.txt'
            return response
        except Liste.DoesNotExist:
            error_message = "La liste sélectionnée n'existe pas."
            return render(request, 'liste_download.html', {'error_message': error_message})
    else:
        form = ListeDownloadForm()
        return render(request, 'liste_download.html', {'form': form})