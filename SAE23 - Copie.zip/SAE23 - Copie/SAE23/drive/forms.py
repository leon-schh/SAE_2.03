from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class CategorieForm(ModelForm):
    class Meta:
        model = models.Categorie
        fields = ('id','nom','descriptif')
        labels = {
            'id' : _('id'),
            'nom' : _('nom'),
            'Descriptif' : _('Descriptif'),
        }


class ProduitForm(ModelForm):
    class Meta:
        model=models.Produit
        fields=('id','nom','date_de_peremption','photo','marque','prix')
        labels={
            'id': _('id'),
            'nom': _('Nom du Produit'),
            'date_de_peremption': _('date de peremption'),
            'photo': _('photo'),
            'marque': _('marque'),
            'prix' : _('Prix'),
        }

class ClientForm(ModelForm):
    class Meta:
        model=models.Client
        fields=('num_client','nom','prenom','date_inscription','adresse')
        labels={
            'num_client': _('num_client'),
            'nom': _('Nom'),
            'prenom': _('Prenom'),
            'date_inscription': _('date_inscription'),
            'adresse': _('adresse'),
        }

class CommandeForm(ModelForm):
    class Meta:
        model=models.Commande
        fields=('num_commande','date')
        labels={
            'num_commande': _('num_commande'),
            'date': _('date'),
        }

class ProdForm(ModelForm):
    class Meta:
        model=models.Prod
        fields=('quantite','nomprod')
        labels={
            'quantite': _('Quantité'),
            'nomprod': _('Produit'),
        }