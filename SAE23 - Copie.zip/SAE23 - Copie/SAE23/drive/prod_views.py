from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import ProdForm
from . import models


def ajout(request,id):
    commande = models.Commande.objects.get(pk=id) # méthode pour récupérer les données dans la base avec un id donnée
    form=ProdForm()
    return render(request,"prod/ajout.html",{"form":form,"id":id,"commande":commande})


def traitement(request,id):
    lform=ProdForm(request.POST)
    if lform.is_valid():
        commande = models.Commande.objects.get(pk=id)
        produit = lform.save(commit=False)
        produit.commande = commande
        produit.commande_id = id
        produit.save()
        return HttpResponseRedirect(f"/drive/afficheprod/{id}/")
    else:
        return render(request, "produit/ajout.html", {"form": lform, "id": id})

def affiche(request, id):
    liste = list(models.Prod.objects.all())
    return render(request,"prod/affiche.html",{"liste":liste,"id":id})


def delete(request,id):
    produit = models.Prod.objects.get(pk=id)
    produit.delete()
    return HttpResponseRedirect(f"/drive/afficheprod/{produit.commande_id}/")


