from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import ProdForm
from . import models


def ajout(request,id):
    form=ProdForm()
    commande = models.Commande.objects.get(pk=id)
    return render(request,"prod/ajout.html",{"form":form,"id":id})


def traitement(request,id):
    lform=ProdForm()
    if lform.is_valid():
        categorie = models.Commande.objects.get(pk=id)
        produit = lform.save(commit=False)
        produit.categorie = categorie
        produit.categorie_id = id
        produit.save()
        return HttpResponseRedirect(f"/drive/ajoutprod/{id}/")
    else:
        return render(request, "produit/ajout.html", {"form": lform, "id": id})



def affiche(request, id):
    commande = models.Commande.objects.get(pk=id) # méthode pour récupérer les données dans la base avec un id donnée
    prod = models.Prod.objects.all()
    return render(request,"prod/affiche.html",{"prod": prod,"commande":commande})


def delete(request):
    produit = models.Produit.objects.get(pk=id)
    produit.delete()
    return HttpResponseRedirect(f"/drive/afficheprod/{produit.categorie_id}/")

