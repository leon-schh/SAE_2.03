from django.db import models

class Categorie(models.Model):
    id = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=100)
    descriptif = models.TextField(null = True, blank = True)

    def __str__(self):
        chaine = f"{self.nom} {self.descriptif} "
        return chaine

    def dico(self):
        return {"id":self.id,"nom":self.nom,"descriptif":self.descriptif}

class Produit(models.Model):
    id = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=100)
    date_de_peremption = models.DateField(blank=True, null=True)
    photo=models.ImageField(upload_to="media/logo/", default="media/logo/default.png")
    marque = models.CharField(max_length=100)
    prix = models.FloatField(default=False)
    categorie=models.ForeignKey("Categorie",on_delete=models.CASCADE,default=None)



    def __str__(self):
        chaine=f" {self.categorie} : {self.nom} "
        return chaine

    def dico(self):
        return {"id":self.id,"nom":self.nom,"date_de_peremption":self.date_de_peremption,"photo":self.photo,"marque":self.marque}

class Client(models.Model):
    num_client=models.IntegerField(blank=False)
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    date_inscription= models.DateField(blank=True, null=True)
    adresse=models.CharField(max_length=100)

    def __str__(self):
        chaine= f"{self.nom} {self.prenom} s'est inscrit le {self.date_inscription}, il est domicilié à {self.adresse}."
        return chaine

    def dico(self):
        return {"num_client":self.num_client,"nom":self.nom,"prenom": self.prenom,"date_inscription":self.date_inscription,"adresse":self.adresse}

class Commande(models.Model):
    num_commande=models.IntegerField(blank=False, default=False)
    date=models.DateField(blank=True, null=True)
    client=models.ForeignKey("Client",on_delete=models.CASCADE,default=None)

    def __str__(self):
        chaine=f"{self.num_commande}{self.date}"
        return chaine

    def dico(self):
        return {"num_commande":self.num_commande,"date":self.date}


class Prod(models.Model):
    quantite=models.PositiveIntegerField(default=0)
    nomprod=models.ForeignKey("Produit",on_delete=models.CASCADE,blank=True)
    commande=models.ForeignKey("Commande",on_delete=models.CASCADE,default=None)
    def __str__(self):
        chaine=f"{self.quantité}{self.nomprod}"
        return chaine

    def dico(self):
        return {"quantite":self.quantite,"nomprod":self.nomprod}