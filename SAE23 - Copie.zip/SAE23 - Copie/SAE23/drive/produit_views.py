from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import ProduitForm
from . import models
import os
from django.conf import settings

def ajout(request,id):
    form = ProduitForm() # création d'un formulaire vide
    return render(request,"produit/ajout.html",{"form" : form,"id":id})

def traitement(request,id):
    lform = ProduitForm(request.POST,request.FILES)
    if lform.is_valid():
        categorie=models.Categorie.objects.get(pk=id)
        produit = lform.save(commit=False)
        produit.categorie=categorie
        produit.categorie_id=id
        produit.save()
        return HttpResponseRedirect(f"/drive/affichecategorie/{id}/")
    else:
        return render(request,"produit/ajout.html",{"form": lform,"id":id})

def index(request):
    liste= list(models.Produit.objects.all())
    return render(request,"produit/index.html",{"liste":liste})

def affiche(request, id):
    liste= list(models.Produit.objects.all())
    produit = models.Produit.objects.get(pk=id) # méthode pour récupérer les données dans la base avec un id donnée
    return render(request,"produit/affiche.html",{"produit": produit,"liste":liste})

def update(request,id):
    produit= models.Produit.objects.get(pk=id)
    form=ProduitForm(produit.dico())
    return render(request,"produit/update.html",{"form":form,"id":id,"produit":produit.nom})

def updatetraitement(request,id):
    produit2 = models.Produit.objects.get(pk=id)
    lform = ProduitForm(request.POST,request.FILES)
    if lform.is_valid():
        produit = lform.save(commit=False)
        produit.categorie=produit2.categorie
        produit.categorie_id = produit2.categorie_id
        produit.id=id
        produit.save()
        return HttpResponseRedirect(f"/drive/affichecategorie/{produit2.categorie_id}/")
    else:
        return render(request, "produit/ajout.html", {"form": lform,"id":id})


def delete(request,id):
    produit = models.Produit.objects.get(pk=id)
    produit.delete()
    return HttpResponseRedirect(f"/drive/affichecategorie/{produit.categorie_id}/")

def is_txt_file(file_path):
    a = []
    a = file_path.split('.')
    return a[1] == 'txt'


def charger_txt(file_path, x):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        data = [line.strip() for line in lines]
        return data[x]


def upload_file(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['fileToUpload']
        file_name = uploaded_file.name
        if is_txt_file(file_name):
            save_path = os.path.join(settings.MEDIA_ROOT, "temp.txt")
            with open(save_path, 'wb') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            nom = str(charger_txt("administration/media/temp/temp.txt", 0))
            serveur_id = int(charger_txt("administration/media/temp/temp.txt", 1))
            utilisateur_id = int(charger_txt("administration/media/temp/temp.txt", 2))

            # Récupérer les objets serveur et utilisateur correspondants
            serveur = models.serveurs.objects.get(pk=serveur_id)
            utilisateur = models.utilisateurs.objects.get(pk=utilisateur_id)
            application = models.applications(nom=nom, serveur=serveur, utilisateur=utilisateur)
            application.save()
            return render(request, "administration/Application/traitement-ajout.html", {"application": application})
        else:
            return render(request, "administration/Application/erreur.html")
    return render(request, "administration/Application/ajout2.html")
