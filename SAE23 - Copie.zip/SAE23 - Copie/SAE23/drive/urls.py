from django.urls import path
from . import views,commande_views,produit_views,client_views,prod_views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns=[
    #pages pour categorie
    path('ajoutcategorie/', views.ajout),
    path('indexcategorie/', views.index),
    path('traitementcategorie/', views.traitement),
    path('affichecategorie/<int:id>/', views.affiche),
    path("updatecategorie/<int:id>/", views.update),
    path("updatetraitementcategorie/<int:id>/", views.updatetraitement),
    path("deletecategorie/<int:id>/", views.delete),
    #page pour client
    path('ajoutclient/', client_views.ajout),
    path('traitementclient/', client_views.traitement),
    path('indexclient/', client_views.index),
    path('afficheclient/<int:id>/', client_views.affiche),
    path("updateclient/<int:id>/", client_views.update),
    path("updatetraitementclient/<int:id>/", client_views.updatetraitement),
    path("deleteclient/<int:id>/", client_views.delete),
    #page pour commande
    path('ajoutcommande/<int:id>/', commande_views.ajout),
    path('traitementcommande/<int:id>/', commande_views.traitement),
    path('indexcommande/', commande_views.index),
    path('affichecommande/<int:id>/', commande_views.affiche),
    path("updatecommande/<int:id>/", commande_views.update),
    path("updatetraitementcommande/<int:id>/", commande_views.updatetraitement),
    path("deletecommande/<int:id>/", commande_views.delete),
    #page pour ajout d'un produit dans une commande
    path("ajoutprod/<int:id>/",prod_views.ajout),
    path("traitementprod/<int:id>/",prod_views.traitement),
    path("afficheprod/<int:id>/",prod_views.affiche),
    path("deleteprod/",prod_views.delete),
    #page pour produit:
    path('ajoutproduit/<int:id>/', produit_views.ajout),
    path('traitementproduit/<int:id>/', produit_views.traitement),
    path('indexproduit/', produit_views.index),
    path('afficheproduit/<int:id>/', produit_views.affiche),
    path("updateproduit/<int:id>/", produit_views.update),
    path("updatetraitementproduit/<int:id>/", produit_views.updatetraitement),
    path("deleteproduit/<int:id>/", produit_views.delete),

]

