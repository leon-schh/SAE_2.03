from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import CategorieForm
from . import models
import os
from django.conf import settings


def ajout(request):
    form = CategorieForm # création d'un formulaire vide
    return render(request,"categorie/ajout.html",{"form" : form})

def traitement(request):
    lform = CategorieForm(request.POST)
    if lform.is_valid():
        categorie = lform.save()
        return HttpResponseRedirect("/drive/indexcategorie/")
    else:
        return render(request,"drive/ajoutcategorie.html",{"form": lform})

def index(request):
    liste= list(models.Categorie.objects.all())
    return render(request,"categorie/index.html",{"liste":liste})

def affiche(request, id):
    categorie = models.Categorie.objects.get(pk=id) # méthode pour récupérer les données dans la base avec un id donnée
    liste=models.Produit.objects.filter(categorie_id=id)
    return render(request,"categorie/affiche.html",{"categorie": categorie,"liste":liste})

def update(request,id):
    categorie = models.Categorie.objects.get(pk=id)
    form=CategorieForm(categorie.dico())
    return render(request,"categorie/update.html",{"form":form,"id":id,"categorie":categorie.nom})

def updatetraitement(request,id):
    lform = CategorieForm(request.POST)
    if lform.is_valid():
        categorie = lform.save(commit=False)
        categorie.id=id
        categorie.save()
        return HttpResponseRedirect("/drive/indexcategorie/")
    else:
        return render(request, "categorie/ajout.html", {"form": lform,'id':id})


def delete(request,id):
    categorie = models.Categorie.objects.get(pk=id)
    categorie.delete()
    return HttpResponseRedirect("/drive/indexcategorie/")

def is_txt_file(file_path):
    a = []
    a = file_path.split('.')
    return a[1] == 'txt'


def charger_txt(file_path, x):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        data = [line.strip() for line in lines]
        return data[x]


def upload_file(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['fileToUpload']
        file_name = uploaded_file.name
        if is_txt_file(file_name):
            save_path = os.path.join(settings.MEDIA_ROOT, "media/temp.txt")
            with open(save_path, 'wb') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            nom = str(charger_txt("media/temp.txt", 0))
            date_de_peremption = str(charger_txt("media/temp.txt", 1))
            marque= str(charger_txt("media/temp.txt", 2))
            prix = float(charger_txt("media/temp.txt", 3))
            categorie_id=int(charger_txt("media/temp.txt",4))
            # Récupérer les objets serveur et utilisateur correspondants
            categorie = models.Categorie.objects.get(pk=categorie_id)
            produit = models.Produit(nom=nom, date_de_peremption=date_de_peremption,marque=marque,prix=prix,categorie=categorie_id)
            produit.save()
            return render(request, "/catgeorie/traitement-ajout.html", {"produit": produit})
        else:
            return render(request, "administration/Application/erreur.html")
    return render(request, "administration/Application/ajout2.html")


